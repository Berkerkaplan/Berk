package commons;

public enum ElementType {
    id,
    name,
    className,
    xpath,
    cssSelector,
    linkText,
    partialLinkText,
    tagName
}