package commons;

import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.javanet.NetHttpTransport;

import java.io.IOException;
import java.util.ArrayList;

public class DeviceFarmFuntions {
    Parser parser = new Parser();

    public String getDevices() {
        return executeGetRequest("devices");
    }

    public String getDevices(String deviceStatus) {
        return executeGetRequest("devices?deviceStatus=" + deviceStatus);
    }

    public String getDevicesAppInstalled(String installedAppPackageInfo) {
        return executeGetRequest("apk/apps-device?packageName=" + installedAppPackageInfo);
    }

    private String executeGetRequest(String url) {
        HttpRequestFactory requestFactory = new NetHttpTransport().createRequestFactory();
        HttpRequest request = null;
        String farmApiKey = "EsXToBkvOT.ckz4iIeqrlRh9JskH8fycZ1JR2g0pQciAPk2OG2M";

        try {
            String farmApiUrl = "http://10.86.163.18/api/";
            request = requestFactory.buildGetRequest(new GenericUrl(farmApiUrl + "" + url));
        } catch (IOException e) {
            e.printStackTrace();
        }

        HttpHeaders headers = new HttpHeaders();
        headers.set("X-VisiumFarm-API-Key", farmApiKey);
        request.setHeaders(headers);
        String rawResponse = null;

        try {
            rawResponse = request.execute().parseAsString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return rawResponse;
    }

    public ArrayList<Device> getDeviceList(String deviceStatus) {
        return parser.parseAndReturnDevices(getDevices(deviceStatus));
    }

    public ArrayList<Device> getDeviceList(String deviceStatus, String OS) {
        ArrayList<Device> devicesTemp = new ArrayList<>();
        ArrayList<Device> devices = parser.parseAndReturnDevices(getDevices(deviceStatus));
        // "os" : "ANDROID","os" : "IOS",
        for (Device device : devices) {
            if (device.getOS().equalsIgnoreCase(OS)) {
                devicesTemp.add(device);
            }
        }
        return devicesTemp;
    }

    public ArrayList<Device> getDeviceList(String deviceStatus, String OS, String packageName) {

        ArrayList<Device> devicesTemp = new ArrayList<>();
        ArrayList<Device> devices = getDeviceList(deviceStatus, OS);
        ArrayList<Device> devicesAppInstalled = parser.parsePackageInstalledDeviceList(getDevicesAppInstalled(packageName));
        // "os" : "ANDROID","os" : "IOS",
        for (Device deviceAppInstallaed : devicesAppInstalled) {
            for (Device device : devices) {
                if (deviceAppInstallaed.getDeviceId().equalsIgnoreCase(device.getDeviceId())) {
                    devicesTemp.add(device);
                }
            }
        }
        return devicesTemp;
    }

    public ArrayList<Device> getDeviceList(String deviceStatus, String OS, String packageName, Boolean automationStatus) {

        ArrayList<Device> devicesTemp = new ArrayList<>();
        ArrayList<Device> devices = getDeviceList(deviceStatus, OS, packageName);
        // "os" : "ANDROID","os" : "IOS",

        for (Device device : devices) {
            if (device.getAutomationStatus() == automationStatus) {
                devicesTemp.add(device);
            }
        }
        return devicesTemp;
    }

}
