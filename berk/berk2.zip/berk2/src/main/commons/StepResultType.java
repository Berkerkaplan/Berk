package commons;

public enum StepResultType {
   PASS,
   FAIL,
   INFO
}