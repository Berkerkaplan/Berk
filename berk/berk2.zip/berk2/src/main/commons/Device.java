package commons;

public class Device {
    private String deviceId;
    private String deviceModel;
    private String brand;
    private String OS;
    private String screenSize;
    private String screenResolution;
    private String deviceStatus;
    private Boolean automationStatus;
    private Boolean developmentStatus;
    private Boolean manualStatus;
    private Boolean reservedStatus;
    private String osVersion;

    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }

    public Boolean getAutomationStatus() {
        return automationStatus;
    }

    public void setAutomationStatus(Boolean automationStatus) {
        this.automationStatus = automationStatus;
    }

    public Boolean getDevelopmentStatus() {
        return developmentStatus;
    }

    public void setDevelopmentStatus(Boolean developmentStatus) {
        this.developmentStatus = developmentStatus;
    }

    public Boolean getManualStatus() {
        return manualStatus;
    }

    public void setManualStatus(Boolean manuelStatus) {
        this.manualStatus = manuelStatus;
    }

    public Boolean getReservedStatus() {
        return reservedStatus;
    }

    public void setReservedStatus(Boolean reservedStatus) {
        this.reservedStatus = reservedStatus;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceModel() {
        return deviceModel;
    }

    public void setDeviceModel(String deviceModel) {
        this.deviceModel = deviceModel;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getOS() {
        return OS;
    }

    public void setOS(String OS) {
        this.OS = OS;
    }

    public String getScreenSize() {
        return screenSize;
    }

    public void setScreenSize(String screenSize) {
        this.screenSize = screenSize;
    }

    public String getScreenResolution() {
        return screenResolution;
    }

    public void setScreenResolution(String screenResolution) {
        this.screenResolution = screenResolution;
    }

    public String getDeviceStatus() {
        return deviceStatus;
    }

    public void setDeviceStatus(String deviceStatus) {
        this.deviceStatus = deviceStatus;
    }

    public String getOsVersion() {
        return osVersion;
    }
}
