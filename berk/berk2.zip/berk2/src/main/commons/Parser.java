package commons;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.FileSystems;
import java.nio.file.Paths;
import java.util.ArrayList;

public class Parser {
    JSONParser parser = new JSONParser();


    static String json;
    static String appsJsonPath =  Paths.get("").toAbsolutePath().toString()+"\\src\\test\\resources\\apps\\";

    public Parser() {
        this.parser = parser;
        this.json =setupPath();
        appsJsonPath =  setupAppsPath();
    }


    public  String setupPath(){
        String osName = System.getProperty("os.name");
        String path="";
        if (osName.toLowerCase().contains("mac")) {
            path = Paths.get("").toAbsolutePath().toString() + "/src/test/java/cucumber/elements/";
        } else if (osName.toLowerCase().contains("win")) {
            path= Paths.get("").toAbsolutePath().toString() + "\\src\\test\\java\\cucumber\\elements\\";
        }
        return path;
    }

    public  String setupAppsPath(){
        String osName = System.getProperty("os.name");
        String path="";
        if (osName.toLowerCase().contains("mac")) {
            path = Paths.get("").toAbsolutePath().toString() + "/src/test/resources/apps/";
        } else if (osName.toLowerCase().contains("win")) {
            path= Paths.get("").toAbsolutePath().toString() + "\\src\\test\\resources\\apps\\";
        }
        return path;
    }

    public Page getPageAttributes(String mypage) throws IOException, ParseException {
        Page returnPage = new Page();
        JSONObject object = null;
        try {
            object = (JSONObject) parser.parse(new FileReader(json + "" + mypage + ".json"));
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        JSONArray array = (JSONArray) object.get("pages");
        String value = null;
        String parentName = "";
        for (Object o : array) {
            JSONObject page = (JSONObject) o;

            JSONObject pageInfo = (JSONObject) page.get("pageInfo");
            String pagename = (String) pageInfo.get("pageName");
            if (pagename.equalsIgnoreCase(mypage)) {
                returnPage.setPageName((String) pageInfo.get("pageName"));
                returnPage.setParentName((String) pageInfo.get("parentName"));
                returnPage.setWaitElement((String) pageInfo.get("waitElement"));
                break;
            }
        }
        return returnPage;
    }

    public Boolean isPageExist(String mypage) {
        JSONObject object = null;
        try {
            object = (JSONObject) parser.parse(new FileReader(json + "" + mypage + ".json"));
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
        JSONArray array = (JSONArray) object.get("pages");

        for (Object o : array) {
            JSONObject page = (JSONObject) o;

            JSONObject pageInfo = (JSONObject) page.get("pageInfo");
            String pagename = (String) pageInfo.get("pageName");

            if (pagename.equalsIgnoreCase(mypage)) {
                System.out.println(pagename + " sayfası bulundu");
                return true;
            }
        }
        return false;
    }

    public Element getElement(String mypage, String myelement) throws UnsupportedEncodingException {
        Element returnElement = new Element();
        JSONObject object = null;
        try {
            object = (JSONObject) parser.parse(new FileReader(json + "" + mypage + ".json"));
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        JSONArray array = (JSONArray) object.get("pages");
        String value = null;
        String parentName = "";
        for (Object o : array) {
            JSONObject page = (JSONObject) o;

            JSONObject pageInfo = (JSONObject) page.get("pageInfo");
            String pagename = (String) pageInfo.get("pageName");
            parentName = (String) pageInfo.get("parentName");
            boolean elemFind = false;
            if (pagename.equalsIgnoreCase(mypage)) {
                JSONArray elements = (JSONArray) page.get("elements");
                for (Object element : elements) {
                    JSONObject elem = (JSONObject) element;
                    value = (String) elem.get("elementName");

                    if (value.equals(myelement)) {

                        returnElement.setAndroidValue(String.valueOf(elem.get("AndroidValue")));
                        returnElement.setIOSValue((String) elem.get("IOSValue"));
                        returnElement.setAndroidType((String) elem.get("AndroidType"));
                        returnElement.setIOSType((String) elem.get("IOSType"));
                        elemFind = true;
                        break;
                    }
                }

                //control parent
                if (elemFind == false && parentName.length() > 0) {
                    JSONObject parentobject = null;
                    try {
                        parentobject = (JSONObject) parser.parse(new FileReader(json + "" + parentName + ".json"));
                    } catch (IOException | ParseException e) {
                        e.printStackTrace();
                    }
                    JSONArray parentarray = (JSONArray) parentobject.get("pages");
                    for (Object obj : parentarray) {
                        JSONObject parentPage = (JSONObject) obj;
                        pageInfo = (JSONObject) parentPage.get("pageInfo");
                        pagename = (String) pageInfo.get("pageName");

                        if (pagename.equalsIgnoreCase(parentName)) {
                            JSONArray parenEelements = (JSONArray) parentPage.get("elements");
                            for (Object element : parenEelements) {
                                JSONObject elem = (JSONObject) element;
                                value = (String) elem.get("elementName");

                                if (value.equals(myelement)) {
                                    returnElement.setAndroidValue((String) elem.get("AndroidValue"));
                                    returnElement.setIOSValue((String) elem.get("IOSValue"));
                                    returnElement.setAndroidType((String) elem.get("AndroidType"));
                                    returnElement.setIOSType((String) elem.get("IOSType"));
                                    elemFind = true;
                                    break;
                                }
                            }
                            if (elemFind == true) {
                                break;
                            }
                        }
                    }
                }
            }
            if (elemFind == true) {
                break;
            }
        }

        return returnElement;
    }

    public ArrayList<Device> parseAndReturnDevices(String devicesJson) {
        ArrayList<Device> devices = new ArrayList<Device>();

        JSONArray jsonArray = null;
        try {
            jsonArray = (JSONArray) parser.parse(devicesJson);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (!jsonArray.isEmpty() && jsonArray != null) {
            for (Object o : jsonArray) {
                Device device = new Device();
                JSONObject deviceInfo = (JSONObject) o;

                device.setDeviceId(deviceInfo.get("deviceId").toString());
                device.setDeviceModel(deviceInfo.get("deviceModel").toString());
                device.setBrand(deviceInfo.get("brand").toString());
                device.setOS(deviceInfo.get("os").toString());
                device.setScreenSize(deviceInfo.get("screenSize").toString());
                device.setScreenResolution(deviceInfo.get("screenResolution").toString());
                device.setDeviceStatus(deviceInfo.get("deviceStatus").toString());
                device.setOsVersion(deviceInfo.get("osversion").toString());

                JSONObject status = (JSONObject) deviceInfo.get("status");

                device.setAutomationStatus(Boolean.valueOf(status.get("Automation").toString()));
                device.setDevelopmentStatus(Boolean.valueOf(status.get("Development").toString()));
                device.setManualStatus(Boolean.valueOf(status.get("Manual").toString()));
                device.setReservedStatus(Boolean.valueOf(status.get("Reserved").toString()));

                devices.add(device);
            }
        }

        return devices;
    }

    public ArrayList<Device> parsePackageInstalledDeviceList(String devicesJson) {
        ArrayList<Device> devices = new ArrayList<Device>();

        JSONArray jsonArray = null;
        try {
            jsonArray = (JSONArray) parser.parse(devicesJson);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (!jsonArray.isEmpty() && jsonArray != null) {
            for (Object o : jsonArray) {
                Device device = new Device();
                JSONObject deviceInfo = (JSONObject) o;

                device.setDeviceId(deviceInfo.get("deviceId").toString());
                String packageName=deviceInfo.get("packageName").toString();

                devices.add(device);
            }
        }

        return devices;
    }
    public String getIOSBundle(String fileName,String myAppName)
    {
        String bundleID=null;
        JSONObject object = null;
        try {
            object = (JSONObject) parser.parse(new FileReader(appsJsonPath+""+fileName+".json"));
        }
        catch (IOException | ParseException e)
        {
            e.printStackTrace();
        }
        try {
            JSONArray array = (JSONArray) object.get("apps");
            for (Object o : array) {
                JSONObject appName = (JSONObject) o;
                String appNameStr = (String) appName.get("appName");
                if(myAppName.equals(appNameStr)){
                    bundleID=(String) appName.get("bundleId");
                    break;
                }
            }
        } catch (Exception e){

        }

        return bundleID;
    }

    public ArrayList<String> getAndroidPackageAndActivity(String fileName, String myAppName)
    {
        JSONObject object = null;
        ArrayList<String> appDetails = new ArrayList<>();
        try {
            object = (JSONObject) parser.parse(new FileReader(appsJsonPath+""+fileName+".json"));
        }
        catch (IOException | ParseException e)
        {
            e.printStackTrace();
        }
        try {
            JSONArray array = (JSONArray) object.get("apps");
            for (Object o : array) {
                JSONObject appName = (JSONObject) o;
                String appNameStr = (String) appName.get("appName");

                if(myAppName.equals(appNameStr)){
                    String appPackage= (String) appName.get("appPackage");
                    String appActivity= (String) appName.get("appActivity");
                    appDetails.add(appPackage);
                    appDetails.add(appActivity);
                    break;
                }
            }
        } catch (Exception e){

        }
        return appDetails;
    }

}