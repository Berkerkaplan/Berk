package commons;

public class AutomationConstants {
    //db constants for MCCMTST1
    public static String MCCMBUST="jdbc:oracle:thin:@172.31.60.134:1521:MCCMTST1";
    public static String MCCMUsername="PEGA_DATA_PROD_SAT";
    public static String MCCMPassword="PEGA_DATA_PROD_SAT";
}
