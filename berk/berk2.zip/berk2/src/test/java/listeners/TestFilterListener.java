package listeners;

import org.testng.*;
import org.testng.xml.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.*;
import java.util.regex.Pattern;

public class TestFilterListener implements IMethodInterceptor {

	private static Set<Pattern> patterns;
	
	
	private boolean includeTest(String testsToInclude,String currentTestName) {
		boolean result = false;
		
		if(patterns==null) {
			patterns = new HashSet<>();
			String[] testPatterns = testsToInclude.split(",");
			for(String testPattern:testPatterns) {
				patterns.add(Pattern.compile(testPattern, Pattern.CASE_INSENSITIVE));
			}
		}
		
		for(Pattern pattern:patterns) {
			if(pattern.matcher(currentTestName).find()) {
				result = true;
				break;
			}
		}
		
		return result;
	}
//	@Override
//	public List<IMethodInstance> intercept(List<IMethodInstance> methods, ITestContext context) {
//		String testNames = System.getProperty("testname");
//		System.out.println(testNames);
//		IMethodInstance e;
//
//		if(testNames==null || testNames.trim().isEmpty()) {
//
//		}else {
//			if(includeTest(testNames, context.getName())) {
//
//			}else if(testNames.length()>0){
//
//				TestNG tng = new TestNG();
//				String xml ="<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
//						"<!DOCTYPE suite SYSTEM \"http://testng.org/testng-1.0.dtd\">"+
//						"<suite name=\"Suite\">"+
//						"<test name=\"deneme12345678\" enabled=\"true\">"+
//						"<classes>"+
//						"<class name=\"runners.MyVodafoneProdBundle.MyVodafoneProdBundleAndroidTestRunner2\"/>"+
//						"<parameter name=\"ChooseDeviceRandom\" value=\"false\"/>"+
//						"<parameter name=\"OSType\" value=\"Android\"/>"+
//						"<parameter name=\"deviceName\" value=\"RF8NC10L9ZP\"/>"+
//						"<parameter name=\"platformVersion\" value=\"11\"/>"+
//						"<parameter name=\"udid\" value=\"RF8NC10L9ZP\"/>"+
//						"<parameter name=\"appPackage\" value=\"com.vodafone.selfservis.beta\"/>"+
//						"<parameter name=\"appActivity\" value=\"com.vodafone.selfservis.modules.splash.activities.SplashActivity\"/>"+
//						"<parameter name=\"platformName\" value=\"Android\"/>"+
//						"<parameter name=\"HubURL\" value=\"http://10.86.163.18:80/wd/hub\"/>"+
//						"</classes>" +
//						"</test>"+"</suite>";
//				System.out.println(xml);
//				ByteArrayInputStream is = new ByteArrayInputStream(xml.getBytes());
//				try {
//					tng.setXmlSuites(new Parser(is).parseToList());
//				} catch (IOException ex) {
//					ex.printStackTrace();
//				}
//				tng.run();
//			}
//			else{
//
//			}
//		}
//		return methods;
//	}
	@Override
	public List<IMethodInstance> intercept(List<IMethodInstance> methods, ITestContext context) {

		String testNames = System.getProperty("testname");
			System.out.println(testNames);
			//System.out.println("Method-->"+methods.get(0).getMethod());
		if(testNames==null || testNames.trim().isEmpty()) {
			return methods;
		}else {
			if(includeTest(testNames, context.getName())) {
				return methods;
			}
			else{
				return new ArrayList<IMethodInstance>();
			}
		}
	}
}
