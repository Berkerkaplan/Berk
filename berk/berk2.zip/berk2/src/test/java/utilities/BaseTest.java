package utilities;

import commons.Device;
import commons.DeviceFarmFuntions;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

public class BaseTest {
    private final DesiredCapabilitiesUtil desiredCapabilitiesUtil = new DesiredCapabilitiesUtil();
    private DeviceFarmFuntions dff = new DeviceFarmFuntions();

    @BeforeMethod
    @Parameters({"udid", "platformVersion", "OSType", "deviceName", "appPackage", "appActivity", "platformName", "HubURL", "bundleID", "xcodeOrgId", "xcodeSigningId", "updatedWDABundleId", "automationName", "ChooseDeviceRandom"})
    public void setup(String udid, String platformVersion, String OSType, String deviceName, @Optional("") String appPackage, @Optional("") String appActivity, String platformName, String HubURL, @Optional("") String bundleID, @Optional("") String xcodeOrgId, @Optional("") String xcodeSigningId, @Optional("") String updatedWDABundleId, @Optional("") String automationName, @Optional("") Boolean ChooseDeviceRandom) throws IOException {
        Device device = new Device();
        ArrayList<Device> devices = new ArrayList<>();
        if (ChooseDeviceRandom) {
            switch (OSType) {
                case "Android":
                    devices = dff.getDeviceList("0", "ANDROID", appPackage, false);
                    if (!devices.isEmpty()) {
                        System.out.println("Random device os type:" + OSType);
                        device = devices.get(0);
                        DesiredCapabilities caps = desiredCapabilitiesUtil.getDesiredAndroidCapabilities(
                                device.getDeviceId(), device.getOsVersion(), device.getOS(), device.getDeviceModel(), appPackage, appActivity, platformName
                        );
                        System.out.println("Random selected device:" + device.getDeviceId());
                        LocalDriver.setTLDriver(new AndroidDriver<MobileElement>(new URL(HubURL), caps));
                    }
                    break;
                case "IOS":
                    devices = dff.getDeviceList("0", "IOS", appPackage, false);
                    //devicefarm ios fix bekleniyor
                    if (!devices.isEmpty()) {
                        device = devices.get(0);
                    }
                    device = dff.getDeviceList("0", "IOS", appPackage).get(0);
                    break;
            }
        } else {
            if (OSType.equals("Android")) {
                DesiredCapabilities caps = desiredCapabilitiesUtil.getDesiredAndroidCapabilities(udid, platformVersion, OSType, deviceName, appPackage, appActivity, platformName);
                LocalDriver.setTLDriver(new AndroidDriver<MobileElement>(new URL(HubURL), caps));
            } else if(OSType.equals("IOS")) {
                DesiredCapabilities caps = desiredCapabilitiesUtil.getDesiredIOSCapabilities(udid, platformVersion, OSType, deviceName, platformName, bundleID, xcodeOrgId, xcodeSigningId, updatedWDABundleId, automationName);
                LocalDriver.setTLDriver(new IOSDriver<MobileElement>(new URL(HubURL), caps));
            } else {

                DesiredCapabilities caps = desiredCapabilitiesUtil.getDesiredLocalIOSCapabilities(udid, platformVersion, OSType, deviceName, platformName, bundleID, xcodeOrgId, xcodeSigningId, updatedWDABundleId, automationName);
                LocalDriver.setTLDriver(new IOSDriver<MobileElement>(new URL(HubURL), caps));
//                DesiredCapabilities caps = desiredCapabilitiesUtil.getDesiredIOSCapabilities(udid, platformVersion, OSType, deviceName, platformName, bundleID, xcodeOrgId, xcodeSigningId, updatedWDABundleId, automationName);
//                LocalDriver.setTLDriver(new IOSDriver<MobileElement>(new URL(HubURL), caps));
            }
        }
    }

    @AfterMethod
    public synchronized void teardown() {
        //ThreadLocalDriver.getTLDriver().quit();
        LocalDriver.getTLDriver().quit();
    }
}