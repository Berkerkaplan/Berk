package utilities;

import io.appium.java_client.MobileDriver;
import io.appium.java_client.MobileElement;

public class LocalDriver {
    private static MobileDriver<MobileElement>  tlDriver;

    public static  void setTLDriver(MobileDriver<MobileElement> driver) { tlDriver=driver;}


    public static  MobileDriver<MobileElement> getTLDriver() {
        return tlDriver;
    }
}
