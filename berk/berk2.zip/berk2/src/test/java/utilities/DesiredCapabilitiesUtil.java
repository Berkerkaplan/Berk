package utilities;

import org.openqa.selenium.remote.DesiredCapabilities;

public class DesiredCapabilitiesUtil {

    public DesiredCapabilities getDesiredAndroidCapabilities(String udid, String platformVersion,String OSType,String deviceName,String appPackage,String appActivity,String platformName) {
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();

        desiredCapabilities.setCapability("deviceName", deviceName);
        desiredCapabilities.setCapability("platformVersion", platformVersion);
        desiredCapabilities.setCapability("platformName", platformName);
        desiredCapabilities.setCapability("appPackage", appPackage);
        desiredCapabilities.setCapability("appActivity", appActivity);
        desiredCapabilities.setCapability("udid", udid);

        desiredCapabilities.setCapability("noReset", true);
        desiredCapabilities.setCapability("automationName", "uiautomator2");
        desiredCapabilities.setCapability("vf:accessKey", "test.auto.sat:4cbd75ba-9dc7-4442-a081-10f3cea52ee1");

        return desiredCapabilities;
    }

    public DesiredCapabilities getDesiredLocalIOSCapabilities(String udid, String platformVersion,String OSType,String deviceName,String platformName, String bundleID,String xcodeOrgId, String xcodeSigningId, String updatedWDABundleId,String automationName) {
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
        desiredCapabilities.setCapability("udid", udid);
        desiredCapabilities.setCapability("platformVersion", platformVersion);
        desiredCapabilities.setCapability("platformName", "IOS");
        desiredCapabilities.setCapability("bundleID", bundleID);
        desiredCapabilities.setCapability("deviceName", deviceName);
        desiredCapabilities.setCapability("xcodeOrgId", xcodeOrgId);
        desiredCapabilities.setCapability("xcodeSigningId", xcodeSigningId);
        desiredCapabilities.setCapability("updatedWDABundleId", updatedWDABundleId);
        desiredCapabilities.setCapability("automationName", automationName);
        desiredCapabilities.setCapability("newCommandTimeout", 150);

        desiredCapabilities.setCapability("skipUnlock", "true");
        desiredCapabilities.setCapability("noReset", "true");
        return desiredCapabilities;
    }

    public DesiredCapabilities getDesiredIOSCapabilities(String udid, String platformVersion,String OSType,String deviceName,String platformName, String bundleID,String xcodeOrgId, String xcodeSigningId, String updatedWDABundleId,String automationName) {

        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();

        desiredCapabilities.setCapability("deviceName", deviceName);
        desiredCapabilities.setCapability("platformVersion", platformVersion);
        desiredCapabilities.setCapability("automationName", automationName);
        desiredCapabilities.setCapability("udid", udid);
        desiredCapabilities.setCapability("platformName", platformName);
        desiredCapabilities.setCapability("vf:accessKey", "test.auto.sat:4cbd75ba-9dc7-4442-a081-10f3cea52ee1");
        desiredCapabilities.setCapability("bundleId", bundleID);
        desiredCapabilities.setCapability("noReset", true);

        return desiredCapabilities;
    }
//
//    public DesiredCapabilities getDesiredFarmIOSCapabilities(String udid, String platformVersion,String OSType,String deviceName,String platformName, String bundleID,String xcodeOrgId, String xcodeSigningId, String updatedWDABundleId,String automationName) {
//        DesiredCapabilities capabilities = new DesiredCapabilities();
//
//        capabilities.setCapability("deviceName", deviceName);
//        capabilities.setCapability("automationName", automationName);
//        capabilities.setCapability("platformVersion", platformVersion);
//        capabilities.setCapability("platformName", platformName);
//        capabilities.setCapability("udid", udid);
//        capabilities.setCapability("vf:accessKey", "test.auto.sat:4cbd75ba-9dc7-4442-a081-10f3cea52ee1");
//        capabilities.setCapability("bundleId", bundleID);
//        capabilities.setCapability("noReset", "true");
//
//        return capabilities;
//    }

}