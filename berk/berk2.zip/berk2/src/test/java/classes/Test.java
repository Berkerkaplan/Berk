package classes;

import org.json.simple.parser.ParseException;
import org.testng.TestNG;
import org.testng.xml.*;
import runners.MyVodafoneProdBundle.MyVodafoneProdBundleAndroidTestRunner;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class Test {
    public static void main(String[] args) throws IOException, ParseException  {
        TestNG tng = new TestNG();
        String xml ="<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
               "<!DOCTYPE suite SYSTEM \"http://testng.org/testng-1.0.dtd\">"+
               "<suite name=\"Suite\">"+
                 "<test name=\"MyVodafonePostpaid?\" enabled=\"true\">"+
       "<classes>"+
            "<class name=\"runners.MyVodafoneProdBundle.MyVodafoneProdBundleAndroidTestRunner2\"/>"+
            "<parameter name=\"ChooseDeviceRandom\" value=\"false\"/>"+
            "<parameter name=\"OSType\" value=\"Android\"/>"+
            "<parameter name=\"deviceName\" value=\"RF8NC10L9ZP\"/>"+
            "<parameter name=\"platformVersion\" value=\"11\"/>"+
            "<parameter name=\"udid\" value=\"RF8NC10L9ZP\"/>"+
            "<parameter name=\"appPackage\" value=\"com.vodafone.selfservis.beta\"/>"+
            "<parameter name=\"appActivity\" value=\"com.vodafone.selfservis.modules.splash.activities.SplashActivity\"/>"+
            "<parameter name=\"platformName\" value=\"Android\"/>"+
            "<parameter name=\"HubURL\" value=\"http://10.86.163.18:80/wd/hub\"/>"+
        "</classes>" +
        "</test>"+"</suite>";
        System.out.println(xml);
        ByteArrayInputStream is = new ByteArrayInputStream(xml.getBytes());
        tng.setXmlSuites(new Parser(is).parseToList());
        tng.run();
    }


}