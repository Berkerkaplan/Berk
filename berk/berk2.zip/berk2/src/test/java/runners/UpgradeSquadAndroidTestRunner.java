package runners;

import io.cucumber.testng.CucumberFeatureWrapper;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.PickleEventWrapper;
import io.cucumber.testng.TestNGCucumberRunner;
import io.qameta.allure.Attachment;
import org.apiguardian.api.API;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utilities.BaseTest;

@CucumberOptions(

        features = "src/test/java/cucumber/features/UpgradeSquad",
        tags = "@UpgradeSquad",
        //tags = "@TEST-657841,@TEST-657842,@TEST-657839,@TEST-657840,@TEST-657838",
        plugin = {"pretty", "io.qameta.allure.cucumber4jvm.AllureCucumber4Jvm"},
        //        //tags="@TEST-191215, @TEST-191113, @TEST-191114, @TEST-191212, @TEST-191124, @TEST-191111, @TEST-191112, @TEST-191123,@TEST-191116,@TEST-191118,@TEST-191117,@TEST-191120,@TEST-191126,@TEST-191122",
        // tags="@Payment",
        glue= {"stepdef"}

)

public class UpgradeSquadAndroidTestRunner extends BaseTest {

    @API(
            status = API.Status.STABLE
    )
    private TestNGCucumberRunner testNGCucumberRunner;

    //String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
    @BeforeClass(alwaysRun = true)
    public void setUpClass() {
        this.testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
    }

    @Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
    public void feature(PickleEventWrapper pickleWrapper, CucumberFeatureWrapper featureWrapper) throws Throwable {
        this.testNGCucumberRunner.runScenario(pickleWrapper.getPickleEvent());
    }

    @Attachment(value = "Page screenshot", type = "image/png")
    public byte[] saveScreenshot(WebDriver oDriver) {
        return ((TakesScreenshot) oDriver).getScreenshotAs(OutputType.BYTES);
    }

    @DataProvider
    public Object[][] features() {
        return testNGCucumberRunner.provideScenarios();
    }

    @AfterClass(alwaysRun = true)
    public void tearDownClass() {
        testNGCucumberRunner.finish();
    }
}
